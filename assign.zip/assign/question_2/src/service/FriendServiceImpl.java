package service;

import java.util.List;

import beans.Friend;
import dao.FriendDao;
import dao.FriendDaoImpl;

public class FriendServiceImpl implements FriendService {

	private FriendDao fdao;
	
	public FriendServiceImpl(){
		this.fdao=new FriendDaoImpl();
	}
	@Override
	public List<Friend> displayAll() {
		// TODO Auto-generated method stub
		return fdao.display();
	}
	@Override
	public Friend SearchById(int id) {
		// TODO Auto-generated method stub
		return fdao.SerachId(id);
	}
	@Override
	public List<Friend> SearchByName(String name) {
		// TODO Auto-generated method stub
		return fdao.SearchName(name);
	}
	@Override
	public List<Friend> displayHobbie(String h) {
		// TODO Auto-generated method stub
		return fdao.displayH(h);
	}

}
