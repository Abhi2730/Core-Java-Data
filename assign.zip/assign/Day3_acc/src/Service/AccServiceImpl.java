package Service;

import DAO.AccData;
import DAO.AccDataimpl;
import bean.Account;
import bean.Current;
import bean.Demat;
import bean.Saving;

import java.util.Scanner;

public class AccServiceImpl implements AccService{
 private AccData accData;
	public AccServiceImpl() {
		this.accData = new AccDataimpl();
	}

	@Override
	public void getAccDetails() {
			accData.showData();
	}

	
	public boolean creatAc(int ch) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your id");
		int id = sc.nextInt();
		System.out.println("Enter your name");
		String name = sc.next();
	   
		Account a = null;
		switch(ch) {
		case 1:
			a = new Saving(id,name,0);
			break;
		case 2:
			a=new Current(id,name,0);
			break;
		case 3:
			a=new Demat(id,name,0);
			break;
		}
		
		return accData.create(a);
	}

	@Override
	public double checkBalance(int i) {
		
		
		return accData.getB(i);
	}

	@Override
	public void deposit(double amt,int i) {
		accData.setB(amt,i);
		
	}

	@Override
	public void withdraw(double amt1, int i2) {
		accData.widraw(amt1,i2);
		
	}
	 
}
