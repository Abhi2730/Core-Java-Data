package Service;



public interface AccService {

	void getAccDetails();

	boolean creatAc(int ch);

	double checkBalance(int i);

	void deposit(double amt,int i);

	void withdraw(double amt1, int i2);

}
