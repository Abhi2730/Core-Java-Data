package Test;
import java.util.Scanner;
import Service.AccService;
import Service.AccServiceImpl;
public class TestAccount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {
		
		System.out.println("1.AccountDetails 2.Createacc 3.Deposit 4.Withdraw 5.checkBalance");
		int choice = sc.nextInt();
	AccService aservice = new AccServiceImpl();		
	switch(choice) {
		case 1: 
			System.out.println("1.SavingAcc 2.CurrentAcc 3.DematAcc 4.all");
			
		     aservice.getAccDetails();
			
				System.out.println(aservice);
			break;
		case 2: 
			System.out.println("1.Saving 2.Current 3.Demat");
			int ch = sc.nextInt();
			
			boolean status = aservice.creatAc(ch);
			if(status) {
				System.out.println("Account created Successfully");
			}
			else {
				System.out.println("System is down:(");
			}
			break;
		case 3: 
			System.out.println("Enter your id to deposit Balance");
			int i = sc.nextInt();
			System.out.println("Enter the Amount you want to add:");
			double amt = sc.nextDouble();
			aservice.deposit(amt,i);
			break;
		case 4: 
			System.out.println("Enter your id to Withdraw Balance");
			int i2 = sc.nextInt();
			System.out.println("Enter the Amount you want to widraw:");
			double amt1 = sc.nextDouble();
			aservice.withdraw(amt1,i2);
			break;
		case 5: 
			System.out.println("Enter your id to check Balance");
			int i1 = sc.nextInt();
			double b = aservice.checkBalance(i1);
			System.out.println("Your Account balance is :"+b);
			
			break;
		default: System.out.println("invalid");
			break;
			
		}
	System.out.println("touwant to rpeat y/n");
	String s =sc.next();
	if(s.equals("n")) {
		break;
	}
	
		}
	}

}
