package DAO;
import bean.Account;
public class AccDataimpl implements AccData {
	
	static Account[] accArr ;
	static int cnt=0;
	static{
		accArr= new Account[5];
 
	}

	@Override
	public boolean create(Account a) {
		if(cnt<accArr.length) {
      for(Account acc:accArr) {
    	  accArr[cnt]=a;
    	  cnt++;
    	  return true;
      }
      }
	return false;
	
	}
	
	public void showData() {
		
		for(Account acc:accArr) {
			if(acc!=null) {
			System.out.println(acc);
		}
		}
	}

	@Override
	public double getB(int i) {
	  for(Account acc:accArr) {
		if(acc.getId()==i) {
			return acc.getBalance();
		}
	}
	  return 0;
	}

	@Override
	public void setB(double amt,int i) {
		for(Account acc:accArr) {
			if(acc!=null) {
				
			if(acc.getId()==i) {
				
				acc.setBalance(amt);
			}
				
			}else {
				break;
			}
			
		}
	
		
	}

	@Override
	public void widraw(double amt1, int i2) {
		for(Account acc:accArr) {
			if(acc!=null) {
				
			if(acc.getId()==i2) {
				
				double w = acc.getBalance();
				acc.setBalance(w-amt1);
			}
				
			}else {
				break;
			}
			
			
		}
		
		
	}

	
}
