
public class Current extends Account{

	public Current(int id, String name, double balance) {
		super(id, name, balance);
		// TODO Auto-generated constructor stub
	}
	public String ToString() {
		return super.toString();
	}

}
