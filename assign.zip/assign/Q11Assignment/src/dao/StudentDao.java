package dao;

import beans.Student;

public interface StudentDao {

	boolean addL(Student s);

	boolean addF();

}
