package dao;

import java.util.List;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import beans.Student;

public class StudentDaoIml implements StudentDao{
	static List<Student> slist;
	static {
		slist = new ArrayList<>();
	}
	@Override
	public boolean addL(Student s) {
		return slist.add(s);
	}
	@Override
	public boolean addF() {
		try(BufferedWriter bw=new BufferedWriter(new FileWriter("stcsv.txt"));){
			for(Student s:slist) {
				bw.write(s.getId()+","+s.getName()+","+s.getEmail()+","+s.getDegree()+"\n");
				
			}
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
}
