package q2;
import java.util.Scanner;
public class TestStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Student[] s = new Student[2];
		
		
		for(int i=0;i<s.length;i++) {
			System.out.println("Enter Student id");
			int id = sc.nextInt();
			System.out.println("Enter Student Name");
			String name = sc.next();
			System.out.println("Enter marks 1");
			int m1 = sc.nextInt();
			System.out.println("Enter marks 2");
			int m2 = sc.nextInt();
			System.out.println("Enter marks 3");
			int m3 = sc.nextInt();
			
			Student st=new Student(id,name,m1,m2,m3);
		 s[i]=st;
		
		}
	    for(Student st:s) {
	    	System.out.println(st);
	    }
	    sc.close();
	}

}
