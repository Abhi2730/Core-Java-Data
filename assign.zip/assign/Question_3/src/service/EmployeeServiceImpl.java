package service;

import dao.EmployeeDao;
import dao.EmployeeDaoImpl;

import java.util.List;
import java.util.Scanner;

import beans.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	Scanner  sc = new Scanner(System.in);

	EmployeeDao ed =  new EmployeeDaoImpl();
	@Override
	public void displayall() {
		ed.display();
		
	}
	@Override
	public void searchbyid() {
		System.out.println("Enter id to search");
		int id = sc.nextInt();
		
		System.out.println(ed.searchid(id));
		
	}
	@Override
	public void searchbyname() {
		System.out.println("Enter name to find");
		String nm = sc.next();
		System.out.println(ed.searchname(nm));
		
		
	}
	@Override
	public void acceptdept() {
		System.out.println("Enter Deptartment");
		String dept = sc.next();
		List<Employee> e = ed.deptartment(dept);
		System.out.println(e);
		
		
	}
	@Override
	public void searchdsg() {
		System.out.println("Enter designation");
		String dsg = sc.next();
		List<Employee> e = ed.searchbydsg(dsg);
		System.out.println(e);
		
	}

}
