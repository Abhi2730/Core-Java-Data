package test;

import java.util.Scanner;

import service.EmployeeService;
import service.EmployeeServiceImpl;

public class TestEmployee {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		 EmployeeService  es = new EmployeeServiceImpl();
//		 
		 int choice; 
		 
		 do {
		 System.out.println("1. Display All \n2. Search by ID \n3. Search by Name \n4. Display By designation \n5 Display By Department");
		 choice = sc.nextInt();
		 
		 switch(choice) {
		 case 1 :
			 es.displayall();
			 break;
		 case 2 :
			 es.searchbyid();
			 break;
		 case 3 :
			 es.searchbyname();
			 break;
		 case 4 : 
			 es.searchdsg();
			 break;
		 case 5 : 
			es.acceptdept();
			 break;
		 case 0 :
			 System.out.println("Exit...");
			 break;
		default :
			System.out.println("Enter Valid Number");
			break;
		 }
		 }while(choice != 0);
	}

}
