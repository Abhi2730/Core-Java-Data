package dao;

import java.util.List;
//import java.time.LocalDate;
import java.util.ArrayList;
import beans.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	
	static List<Employee> lst;
	static {
		lst = new ArrayList<>();
		lst.add(new Employee (1,"Vedant", "1234", "ved@gamil", "devloper", "microsoft"));
		lst.add(new Employee (2,"Vitthal", "1234", "vittu@gamil", "devloper", "microsoft"));
		lst.add(new Employee (3,"apurva", "1234", "apu@gamil", "devloper", "microsoft"));
		lst.add(new Employee (4,"rutuja", "5678", "rutu@gamil", "testing", "microsoft"));
		lst.add(new Employee (5,"ashwin", "9876", "ash@gamil", "data analyst", "adobe"));
		lst.add(new Employee (6,"pradymn", "5432", "padu@gamil", "hr", "conginzent"));
		lst.add(new Employee (7,"rohit", "5432", "rhya@gamil", "hr", "TCS"));
		lst.add(new Employee (8,"prasad", "5432", "prasu@gamil", "hr", "Accenture"));
	}
	
	
	
	@Override
	public void display() {
		System.out.println(lst);
	}



	@Override
	public Employee searchid(int id) {
		for (Employee e : lst) {
			if(id == e.getId()) {
				return e;
			}
		}
		return null;
		
	}


	@Override
	public Employee searchname(String nm) {
		for (Employee e : lst) {
			if (e.getName().equals(nm)) {
				return e;
			}
			
		}
		return null;
	}


	
	@Override
	public List<Employee> deptartment(String dept) {
		List<Employee> lst1 = new ArrayList<>();
		for (Employee e : lst) {
			if(e.getDept().equals(dept)) {
				lst1.add(e);	
			}	
		}
		return lst1;
	}

	@Override
	public List<Employee> searchbydsg(String dsg) {
		List<Employee> lst2 = new ArrayList();
		for (Employee e : lst) {
			if(e.getDesig().equals(dsg)) {
				lst2.add(e);
			}
		}
		 return lst2;
	}
}
