

import java.util.List;
public class ReadTest {

	public static void main(String[] args) {
		ReadDao rd = new ReadDao();
		List<Student> lt  = rd.displayAll();
		System.out.println(lt);

	}

}
