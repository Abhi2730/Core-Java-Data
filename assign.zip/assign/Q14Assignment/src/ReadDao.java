

import java.util.List;



import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;


public class ReadDao {

	
	public List<Student> displayAll() {
		List<Student> lst = new ArrayList<>();
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("C:\\Users\\IET\\Desktop\\Java Files\\Q13Assignment\\stcsv.txt"));){
			while(true) {
				Student p = (Student)ois.readObject();
				lst.add(p);
			}
				
			
			} catch(EOFException e) {
				System.out.println("Reached End Of Line");
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return lst;
		}
	
	}
	
	
	

