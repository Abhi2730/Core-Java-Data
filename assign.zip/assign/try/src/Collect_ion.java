import java.util.Vector;

public class Collect_ion {

	public static void main(String[] args) {
		
		Vector<Integer> v =new Vector<>();
		
		v.add(12);
		v.add(24);
		v.add(36);
		
		System.out.println(v);
		
		
	}

}
