package service;

import beans.Product;

public interface ProductService {

	void displayAll();

	boolean addItem();

	
}
