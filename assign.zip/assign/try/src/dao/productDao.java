package dao;

public interface productDao {

	void display();

	

}
