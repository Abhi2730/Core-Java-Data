package dao;
import beans.Product;

import java.time.LocalDate;
import java.util.ArrayList;

public class productDaoImpl implements productDao {

	static ArrayList<Product> plist = new ArrayList<>();
	static {
		plist.add(new Product(1,"Maggie",LocalDate.now()));
		plist.add(new Product(2,"Kitkat", LocalDate.of(2025, 03, 12)));
	}
	@Override
	public void display() {
	
		for(Product p : plist) {
			
			System.out.println(p);
			
		}
		
	}
	

}
