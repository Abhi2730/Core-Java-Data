package test;

import java.util.List;
import java.util.Scanner;

import beans.Employee;
import service.TreeService;
import service.TreeServiceImpl;
public class TestTree {
  public static void main(String[] args) {
	  Scanner sc = new Scanner(System.in);
		TreeService emps = new TreeServiceImpl();
		int choice;
		do {
			System.out.println("1.add \n 2.display \n 3.Find By Id \n 4.Exit");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				boolean status = emps.addEmp();
			if(status) {
				System.out.println("Adding successfull");
			}
			else {
				System.out.println("Adding Unsuccessfull");
		}
			break;
			case 2:
				emps.displaayAll();
				break;
			case 4: 
			    System.out.println("Thank you!!");
				break;
			case 3:
				System.out.println("Enter id to find Employee");
				int id = sc.nextInt();
				Employee e1=emps.displayId(id);
				System.out.println(e1);
				break;
			default:
				System.out.println("invalid no.");
				break;
		
		}
		}while(choice!=3);
  }
}
