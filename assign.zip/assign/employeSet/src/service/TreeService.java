package service;

import java.util.List;

import beans.Employee;

public interface TreeService {

	boolean addEmp();

	void displaayAll();

	Employee displayId(int id);

	

}
