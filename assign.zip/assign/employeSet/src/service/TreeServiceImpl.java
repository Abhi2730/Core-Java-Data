package service;

import java.util.Scanner;

import beans.Employee;
import dao.TreeDao;
import dao.TreeDaoImpl;


public class TreeServiceImpl implements TreeService{
	private TreeDao tdao;
	public TreeServiceImpl() {
		this.tdao=new TreeDaoImpl();
	}
	@Override
	public boolean addEmp() {
		Scanner sc = new Scanner(System.in);
		while(true) {
		
		System.out.println("Enter id:");
		int id = sc.nextInt();
		System.out.println("Enter name:");
		String nm = sc.next();
		System.out.println("Enter Salary:");
		double salary = sc.nextDouble();
		System.out.println("Enter department:");
		String dept = sc.next();
		System.out.println("Enter Desgignation:");
		String desg = sc.next();
		
		Employee e = new Employee(id,nm,salary,dept,desg);
		
		System.out.println("Youo want to add y/n");
		String s = sc.next();
		
		return tdao.add(id,e);
		}
	}
	@Override
	public void displaayAll() {
		
		tdao.display();
	}
	@Override
	public Employee displayId(int id) {
		// TODO Auto-generated method stub
		return tdao.findId(id);
	}
}
