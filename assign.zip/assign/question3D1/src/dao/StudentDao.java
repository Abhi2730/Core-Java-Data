package dao;

public interface StudentDao {

	void display();

	void search(int id);
  void searchName(String n);

void calculate();


}
