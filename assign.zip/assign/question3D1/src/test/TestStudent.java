
package test;
import bean.Student;
import java.util.Scanner;
import service.StudentSI;
import service.StudentService;
public class TestStudent {

	public static void main (String[] args) {
		
		Scanner sc = new Scanner(System.in);
	
		int choice;
		do {
		StudentSI ss = new StudentService();
		System.out.println("press \n 1. Display All \n2.Search by ID\n3.search by Name\n 4.Calculate GPA\n5.Exit");
		 choice = sc.nextInt();
		
		switch(choice) {
		case 1:
			ss.displayAll();
			break;
		case 2 :
			System.out.println("Enter ID TO search");
			int id = sc.nextInt();
			
			ss.searchId(id);
			break;
		case 3 :
			System.out.println("Enter Name to searach");
			String name = sc.next();
			
			ss.searchName(name);
			break;
		case 4 :
			ss.CalulateGPA();
			break;
		case 5:
			System.out.println("Thank you!");
			break;
		default:
			System.out.println("------- INVALID ------");
			break;
		
		}
		}while(choice!=5);
		
		
		
	}
}
