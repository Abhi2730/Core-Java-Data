package service;

public interface TeamService {

	boolean addNew();

	void displayAll();

	boolean removeP(int id, String plr);

	boolean removeT(int tid);

	boolean addCoach(int tid, String coach);

	boolean addP(int tid, String pname);



}
