import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;
public class NewException {

	public static void main(String[] args) {
		Map<String,String> mi = new HashMap<>();
		
		mi.put("1","pass1");
		mi.put("2","pass2");
		mi.put("3","pass3");
		
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<3;i++) {
			try {
			System.out.println("Enter USername:");
			String un = sc.next();
			System.out.println("Enter Password:");
			String pass = sc.next();
			
			if(mi.containsKey(un)) {
				if(mi.get(un).equals(pass)) {
					System.out.println("Valid User");
					break;
				}
			}
			else {
				throw new InvalidNoException("Invalid Credidentiols");
			}
			}
		
			catch(InvalidNoException e) {
				System.out.println(e.getMessage());
				//e.printStackTrace();
			}
		}
		System.out.println("Outside try block and loop");
		sc.close();
	}
		
		

	}


