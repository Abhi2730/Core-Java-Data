package test;
import service.FileService;

import java.util.List;
import java.util.Scanner;

import beans.Product;
import service.FileServiceImpl;
public class TestFile {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		FileService pservice = new FileServiceImpl();
		pservice.readFile();
		int choice=0;
		boolean aflag = false;
		boolean mflag = false;
		do {
		System.out.println("1. Add new product\n 2. display all\n 3. delete by id\n");
		System.out.println("4. modify product\n 5. display by id\n 6. exit\n choice: ");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			
			boolean status = pservice.addInList();
			
			if(status) {
				System.out.println("Added Successfully");
			} else {
				System.out.println("Error");
			}
			aflag=true;
			break;
			
		case 2:
			
			List<Product> plist = pservice.readFile();
			
			plist.stream().forEach(System.out::println);
			
			break;
		case 3:
			System.out.println("Enter Id to delete");
			int pid = sc.nextInt();
			
			status = pservice.removeF(pid);
			
			if(status) {
				System.out.println("Deleted Succesfully");
			} else {
				System.out.println("Not Found");
			}
			mflag=true;
			break;
		case 4:
			
			System.out.println("Enter id to update details");
			pid = sc.nextInt();
			status = pservice.updateF(pid);
			if(status) {
				System.out.println("Modified Successfully");
			}else {
				System.out.println("Not Found");
				
			}
			mflag=true;
			break;
		case 5:
			System.out.println("Enter Id to search");
			pid = sc.nextInt();
			
			Product p = pservice.getById(pid);
			if(p!=null) {
				System.out.println(p);
			}else {
				System.out.println("Not Found");
			}
			
			break;
		case 6:
			sc.close();
			System.out.println("Thank you");
			if(aflag) {
				pservice.appendFile();
			}
			else if(mflag){
				pservice.addInFile();
			}
			else {
				System.out.println("Exited without updte");
			}
			
			
			break;
		default:
			System.out.println("invalid choice");
			
		}
		}while(choice!=6);
		
	}


}
