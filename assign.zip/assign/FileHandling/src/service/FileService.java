package service;

import java.util.List;

import beans.Product;

public interface FileService {

	boolean addInList();

	void addInFile();

	List<Product> readFile();

	boolean removeF(int id);

	boolean updateF(int id);

	List<Product> displayAll();

	Product getById(int pid);

	void appendFile();

	

}
