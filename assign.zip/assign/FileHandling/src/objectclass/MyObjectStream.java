package objectclass;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class MyObjectStream extends ObjectOutputStream{

	public MyObjectStream(OutputStream out) throws IOException {
		super(out);
		// TODO Auto-generated constructor stub
	}

	protected MyObjectStream() throws IOException, SecurityException {
		super();
		// TODO Auto-generated constructor stub
	}
	 public void writeStreamHeader() throws IOException
	    {
	        return;
	    }

}
