package dao;

import java.util.List;

import beans.Product;

public interface FileDao {

	boolean addAll(Product p);

	void addFile();

	List<Product> readInFile();

	boolean removeFile(int id);

	boolean updateInF(int id, String name, int price);

	List<Product> display();

	Product searchById(int pid);

	void sppendInFile();

}
