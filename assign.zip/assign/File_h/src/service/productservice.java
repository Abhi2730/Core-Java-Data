package service;

public interface productservice {
	public boolean addfile();
	
}
