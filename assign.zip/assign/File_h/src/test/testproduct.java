package test;
import service.productservice;
import service.productserviceimpl;
public class testproduct {

	public static void main(String[] args) {
		
		productserviceimpl ps = new productserviceimpl();
		ps.addfile();
	}

}
