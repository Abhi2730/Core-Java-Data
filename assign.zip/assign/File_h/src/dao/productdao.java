package dao;
import bean.Product;
public interface productdao {

	boolean addf(Product p);

}
