package buffer;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class testbuffer {

	public static void main(String[] args) {

		
		File f=new File("test.txt");
		
		BufferedOutputStream bos=null;
		
		if(f.exists()) {
			try {
					bos=new BufferedOutputStream(new FileOutputStream(f,true));
			}
			catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		else {
			try {
			bos = new BufferedOutputStream(new FileOutputStream(f));
		}
			catch (FileNotFoundException e){
				e.printStackTrace();
			}
		}
		
		try(BufferedInputStream bis=
				new BufferedInputStream(new FileInputStream("test.txt"));
				BufferedOutputStream bos1=bos; ){	
			
			int i = bis.read();
			while(i != -1) {
				bos.write(i);
				bis.read();
			}
		System.out.println("Done.........");
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	catch (IOException e) {
		e.printStackTrace();
	}
	}
}
