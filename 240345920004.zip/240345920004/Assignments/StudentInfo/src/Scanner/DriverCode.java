package Scanner;

import java.util.Scanner;

public class DriverCode {

	public static void main(String[] args) {
		
		StudentInfo[] sarr=new StudentInfo[5];
		
		StudentServices.SetDetails(sarr);
		
		StudentServices.Displayall(sarr);
		
		System.out.println("Enter name to search");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		StudentInfo Stud=StudentServices.Searchbyname(sarr,name);
		System.out.println(Stud);
		
		System.out.println("Enter ID to search");
		int ID=sc.nextInt();
		StudentInfo Studd=StudentServices.SearchbyID(sarr,ID);
		System.out.println(Studd);
	}

}
