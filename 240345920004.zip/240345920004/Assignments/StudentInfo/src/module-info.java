/**
 * 
 */
/**
 * @author IET
 *
 */
module StudentInfo {
	requires java.sql;
}