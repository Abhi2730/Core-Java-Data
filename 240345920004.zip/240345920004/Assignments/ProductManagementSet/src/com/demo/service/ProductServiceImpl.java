package com.demo.service;
import com.demo.beans.*;

import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class ProductServiceImpl implements ProductService{
	public ProductDao pdao;
	
	public ProductServiceImpl()
	{
		pdao=new ProductDaoImpl();
	}

	@Override
	public boolean addNewProduct() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Product Id");
		int id=sc.nextInt();
		
		System.out.println("Enter Product Name");
		String name=sc.next();
		
		System.out.println("Enter Product Quantity");
		int qty=sc.nextInt();
		
		System.out.println("Enter Product Price");
		float price=sc.nextFloat();
		
		System.out.println("Enter Product Expiry Date in Format(dd/MM/yyyy)");
		String exdate=sc.next();
		
		LocalDate ldt= LocalDate.parse(exdate, DateTimeFormatter.ofPattern("dd/MM/yyyy") );
		
		Product pdt=new Product(id,name,qty,price,ldt);
		
		return pdao.save(pdt);
		
		
	}

	@Override
	public Set<Product> displayAll() {
		
		return pdao.displayAll();
	}

	@Override
	public Product displayById(int id) {
		
		return pdao.findById(id);
	}

	@Override
	public List<Product> displayByName(String name) {
		
		return pdao.findByName(name);
	}

	@Override
	public List<Product> displayByPrice(float price) {
		
		return pdao.findByPrice(price);
	}

	@Override
	public List<Product> sortByName() {
		
		return pdao.arrangeByName();
	}

	@Override
	public List<Product> sortByPrice() {
		
		return pdao.arrangeByPrice();
	}

	@Override
	public Set<Product> sortById() {
		return pdao.arrangeById();
	}

	@Override
	public boolean deleteById(int pid) {
		
		return pdao.removeById(pid);
	}

	@Override
	public boolean modifyProduct(int pid, int qty, float pr) {
		return pdao.modifyProduct(pid,qty,pr);
	}
	
	

}
