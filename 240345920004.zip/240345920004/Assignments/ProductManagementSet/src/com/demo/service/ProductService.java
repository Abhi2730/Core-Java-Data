package com.demo.service;

import java.util.List;
import java.util.Set;

import com.demo.beans.Product;

public interface ProductService {

	boolean addNewProduct();

	Set<Product> displayAll();

	Product displayById(int id);

	List<Product> displayByName(String name);

	List<Product> displayByPrice(float price);

	List<Product> sortByName();

	List<Product> sortByPrice();

	Set<Product> sortById();

	boolean deleteById(int pid);

	boolean modifyProduct(int pid, int qty, float pr);
}
