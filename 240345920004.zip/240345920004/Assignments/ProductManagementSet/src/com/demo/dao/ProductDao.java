package com.demo.dao;

import java.util.List;
import java.util.Set;

import com.demo.beans.Product;

public interface ProductDao {

	boolean save(Product pdt);

	Set<Product> displayAll();

	Product findById(int id);

	List<Product> findByName(String name);

	List<Product> findByPrice(float price);

	List<Product> arrangeByName();

	List<Product> arrangeByPrice();

	Set<Product> arrangeById();

	boolean removeById(int pid);

	boolean modifyProduct(int pid, int qty, float pr);

	

}
