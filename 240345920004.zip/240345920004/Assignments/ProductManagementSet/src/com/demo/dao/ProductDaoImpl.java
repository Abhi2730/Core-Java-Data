package com.demo.dao;

import java.util.Set;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.TreeSet;

import com.demo.beans.Product;
import com.demo.comparators.*;

public class ProductDaoImpl implements ProductDao{

	static Set<Product> pset;
	
	static
	{
		pset = new HashSet<>();
		pset.add(new Product(15,"Maggie",50,60,LocalDate.of(2024, 12, 07)));
		pset.add(new Product(22,"Kurkure",50,30,LocalDate.of(2024, 10, 05)));
		pset.add(new Product(3,"Bourbon",45,65,LocalDate.of(2024, 06, 11)));
		pset.add(new Product(14,"Lays",35,45,LocalDate.of(2024,06, 12)));
		
		
	}

	@Override
	public boolean save(Product pdt) {
		
		return pset.add(pdt);
	}

	@Override
	public Set<Product> displayAll() {
		
		return pset;
	}

	@Override
	public Product findById(int id) {
		for(Product p:pset)
		{
			if(p.getPid()==id)
			{
				return p;
			}
		}
		return null;
	}

	@Override
	public List<Product> findByName(String name) {
		List<Product> list= new ArrayList<>();
		for(Product p:pset)
		{
			if(p.getPname().equals(name))
			{
				list.add(p);
			}
		}
		if(list.isEmpty())
		{
			return null;
		}
		return list;
	}

	@Override
	public List<Product> findByPrice(float price) {
		List <Product> list=new ArrayList<>();
		for(Product p:pset)
		{
			if(p.getPrice()>price)
			{
				list.add(p);
			}
		}
		if(list.isEmpty())
		{
			return null;
		}
			return list;
	}

	@Override
	public List<Product> arrangeByName() {
		List<Product> list=new ArrayList<>();
		for(Product p:pset)
		{
			list.add(p);
		}
		list.sort(new MyNameComparator());
		return list;
	}

	@Override
	public List<Product> arrangeByPrice() {
		List<Product> list = new ArrayList<>();
		for(Product p:pset)
		{
			list.add(p);
		}
		list.sort(new MyPriceComparator());
		return list;
	}

	@Override
	public Set<Product> arrangeById() {
		/*
		 * List<Product> list=new ArrayList<>(); 
		 * for(Product p:pset)
		 *  { 
		 *  list.add(p); 
		 *  }
		 * list.sort(null); 
		 * return list;
		 */
		
		
		Set<Product> tset=new TreeSet<>();
		for(Product p:pset)
		{
			tset.add(p);
		}
		return tset;
	}

	@Override
	public boolean removeById(int pid) {
		
		return pset.remove(new Product(pid));
	}

	@Override
	public boolean modifyProduct(int pid, int qty, float pr) {
		Product p=findById(pid);
		if(p!=null)
		{
			p.setQty(qty);
			p.setPrice(pr);
			return true;
		}
		return false;
	}

	
	
	
	
}
