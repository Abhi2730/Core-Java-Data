import java.util.*;
public class TestMap {

	public static void main(String[] args) {
		
		Map<String , Integer> hm= new HashMap<>();
		hm.put("DAC", 120);
		hm.put("DBDA", 140);
		hm.put("DITIS", 200);
		hm.put("DMC", 60);
		
		System.out.println("Map data : \n"+hm);
		System.out.println(hm.get("DBDA"));
		
		
		hm.put("DBDA",240);
		hm.put("AI", 70);
		
		System.out.println("Map data After modification : \n"+hm);
		
		//check if duplicate key is present and then enter values.
		System.out.println(hm.containsKey("DBDA"));
		if(! hm.containsKey("UnmanedAI"))
		{
			hm.put("UnmanedAI", 500);
		}
		else
		{
			System.out.println("Duplicate key found!");
		}
		
		System.out.println("Map data after new insert: \n"+hm);
		
		//Retrive all keys
		System.out.println("KeySet: \n"+hm.keySet());
		
		//Entryset
		System.out.println("EntrySet: \n "+hm.entrySet());
		
		
		//To find all the keys having value greater than 100
		Set<String> Str1 = hm.keySet();
		System.out.println("Keys are:");
		for(String keys: Str1 )
		{
			if(hm.get(keys)>100)
			{
				
				System.out.println(keys);
			}
		}
		
		
	}

}
