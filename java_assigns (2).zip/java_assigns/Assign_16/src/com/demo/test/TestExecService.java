package com.demo.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.*;
import com.demo.threads.*;


public class TestExecService {

	public static void main(String[] args) {
		  ExecutorService executor = Executors.newFixedThreadPool(5);
	        List<Future<Integer>> futures = new ArrayList<>();

	        for (int i = 0; i < 51; i += 3) {
	            AdditionTask task = new AdditionTask(i, i + 1, i + 2);
	            Future<Integer> future = executor.submit(task);
	            futures.add(future);
	        }

	        int sum = 0;
	        for (Future<Integer> future : futures) {
	            try {
	                sum += future.get();
	            } catch (InterruptedException | ExecutionException e) {
	                e.printStackTrace();
	            }
	        }

	        System.out.println("Sum of 51 numbers: " + sum);

	        executor.shutdown();
	    }

	}


