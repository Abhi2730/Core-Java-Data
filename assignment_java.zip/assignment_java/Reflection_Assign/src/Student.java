
public class Student {
   int Roll_No;
   String Name;
   int Marks1;
   int Marks2;
@Override
public String toString() {
	return "Student [Roll_No=" + Roll_No + ", Name=" + Name + ", Marks1=" + Marks1 + ", Marks2=" + Marks2 + "]";
}
public int getRoll_No() {
	return Roll_No;
}
public void setRoll_No(int roll_No) {
	Roll_No = roll_No;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public int getMarks1() {
	return Marks1;
}
public void setMarks1(int marks1) {
	Marks1 = marks1;
}
public int getMarks2() {
	return Marks2;
}
public void setMarks2(int marks2) {
	Marks2 = marks2;
}
public Student() {
	super();
}

public void  Calc_Marks()
{ 
	int result=Marks1+Marks2;
	System.out.println(result);
}
public Student(int roll_No, String name, int marks1, int marks2) {
	super();
	Roll_No = roll_No;
	Name = name;
	Marks1 = marks1;
	Marks2 = marks2;
}
   
   
}
