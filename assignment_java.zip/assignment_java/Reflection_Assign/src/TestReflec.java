import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.TypeVariable;

public class TestReflec {

	public static void main(String[] args) {
	
      
      Rectangle ob=new Rectangle(10,20);
		Class cls=ob.getClass();
	//to retrieve the constructors
	Constructor[] carr=cls.getConstructors();
	for(Constructor c:carr) 
	{
		System.out.println(c+"---->"+c.getParameterCount());
	}
	//find method names
	Method[] marr=cls.getMethods();
	for(Method m:marr) {
		System.out.println(m.getName()+"---->"+m.getParameterCount());
		TypeVariable[] parr=cls.getTypeParameters();
		
		for(TypeVariable P:parr)
		{
			System.out.println(P);
		}
	}
	
	
	System.out.println("\n\n\n");
	Student ob1=new Student(1,"AAA",10,20);
		Class cls1=ob1.getClass();
	//to retrieve the constructors
	Constructor[] carr1=cls1.getConstructors();
	for(Constructor c1:carr1) 
	{
		System.out.println(c1+"---->"+c1.getParameterCount());
	}
	//find method names
	Method[] marr1=cls1.getMethods();
	for(Method m1:marr1) {
		System.out.println(m1.getName()+"---->"+m1.getParameterCount());
		TypeVariable[] parr1=cls1.getTypeParameters();
		
		for(TypeVariable P1:parr1)
		{
			System.out.println(P1);
		}
	}
	
	System.out.println("\n\n\n");
	
	Friend ob2=new Friend(10,"AAA");
		Class cls2=ob2.getClass();
	//to retrieve the constructors
	Constructor[] carr2=cls2.getConstructors();
	for(Constructor c2:carr2) 
	{
		System.out.println(c2+"---->"+c2.getParameterCount());
	}
	//find method names
	Method[] marr2=cls2.getMethods();
	for(Method m2:marr2) {
		System.out.println(m2.getName()+"---->"+m2.getParameterCount());
		TypeVariable[] parr2=cls2.getTypeParameters();
		
		for(TypeVariable P2:parr2)
		{
			System.out.println(P2);
		}
	}
	
 }

}
