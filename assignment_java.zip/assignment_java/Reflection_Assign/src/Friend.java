
public class Friend {
    public Friend() {
		super();
	}
	public Friend(int id, String name) {
		super();
		this.id = id;
		Name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	int id;
    String Name;
	@Override
	public String toString() {
		return "Friend [id=" + id + ", Name=" + Name + "]";
	}
}
