package com.Dao;

import java.util.Map;

import com.tree.bin.Trees;

public interface TreeDao {

	Map<Integer, String> findbycity(String City);

	void removebyname(String city);

	boolean addata(String city, Map<Integer, String> localmap);

	Map<Integer, Trees> findall();

}
