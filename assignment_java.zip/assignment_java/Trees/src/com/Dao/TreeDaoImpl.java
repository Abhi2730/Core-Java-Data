package com.Dao;
import com.tree.bin.*;
import java.util.Map;
import java.util.HashMap;
public class TreeDaoImpl implements TreeDao{
       static private Map<Integer,Trees> datamap;
       static int icurrobjno;
 
       static 
       {
    	   datamap=new HashMap<Integer,Trees>();
    	   icurrobjno=4;
    	  Trees T1;
    	  Map<Integer,String> s=new HashMap<>();
    	  s.put(1,"Tree1");
                                         	  s.put(2,"Tree2");
    	  s.put(3,"Tree3");
    	  T1=new Trees("Pune",s);
    	  
    	  Trees T2;
    	  Map<Integer,String> v=new HashMap<>();
    	  v.put(4,"Tree4");
    	  v.put(5,"Tree5");
    	  v.put(6,"Tree6");
    	  T2=new Trees("Akola",v);
    	  
    	  Trees T3;
    	  Map<Integer,String> h=new HashMap<>();
    	  h.put(7,"Tree7");
    	  h.put(8,"Tree8");
    	  h.put(9,"Tree9");
    	  T3=new Trees("Nashik",h);
    	datamap.put(1, T1);
    	datamap.put(2, T2);
    	datamap.put(3, T3);
       }
     
       
      
	@Override
	public Map<Integer, String> findbycity(String City) {
		 for (Map.Entry<Integer, Trees> set :
             datamap.entrySet()) {
			 
			       // set.getKey(); 
			        
                    Trees T=set.getValue();
                    
                    if(T.getCity().equals(City))
                    {
                    	return T.getTrees();
                    }
                  
       
        }
		 return null;
	}



	@Override
	public void removebyname(String city) {
		 for (Map.Entry<Integer, Trees> set :
             datamap.entrySet()) {
			 
			 
			        
                    Trees T=set.getValue();
                    
                    if(T.getCity().equals(city))
                    {
                    	datamap.remove(city);
                    	//return datamap;
                    }
                  
       
        }
		//return null;
	}



	@Override
	public boolean addata(String city, Map<Integer, String> localmap) {
		Trees T=new Trees(city,localmap);
	    datamap.put(icurrobjno, T);
		icurrobjno=icurrobjno+1;
		return false;
	}



	@Override
	public Map<Integer, Trees> findall() {
		
		return datamap;
	}
       
       
}
