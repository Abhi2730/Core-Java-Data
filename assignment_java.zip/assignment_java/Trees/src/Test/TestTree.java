package Test;

import java.util.Map;
import java.util.Scanner;
import com.tree.bin.*;

import com.bin.TreeService.*;
public class TestTree {

	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		TreeService tservice=new TreeServiceImpl();
		int Choice=0;
		do {
			
			System.out.println("1.Find List of Trees For A City\n2.Delete List of A Particular City\n"
					+ "3.Add new entree in treemap\n4.Display All City Names\nChoice");
			Choice=Sc.nextInt();
			
			switch(Choice)
			{
			case 1:
				System.out.println("Enter Name of City To search trees");
				String city=Sc.next();
				Map<Integer,String> s=tservice.Displaytrees(city);
				
				 for (Map.Entry<Integer, String> set :
		             s.entrySet()) {
	
		            System.out.println(set.getKey() + " = "
		                               + set.getValue());
		        }
			    
				break;
			case 2:
				System.out.println("Enter Name of City To search trees");
			      city=Sc.next();
				tservice.Deletebycity(city);
				
			    
				break;
			case 3:
				boolean status;
				status=tservice.AddNewCity();
				break;
			case 4:
				
				Map<Integer,Trees> s3=tservice.DisplayAll();
				
				 for (Map.Entry<Integer, Trees> set :
		             s3.entrySet()) 
				 {
                    Trees T= set.getValue();
                   System.out.println(T.getCity()); 
                   System.out.println(T.getTrees());
		         }
			    
				break;
			}
		}while(Choice > 0 && Choice < 5);
		

	}

}
